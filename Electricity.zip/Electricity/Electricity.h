//
//  Electricity.h
//  Unity-iPhone
//
//  Created by 杨晨 on 2017/6/29.
//
//

#import <Foundation/Foundation.h>

@interface Electricity : NSObject
/**
 *
 *  初始化单例
 */
+(instancetype) shareInstance;
/**
 *
 *  调用电量的方法
 */
-(double)getCurrentBatteryLevel;

@end
